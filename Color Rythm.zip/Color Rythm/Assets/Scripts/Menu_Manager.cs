﻿using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Menu_Manager : MonoBehaviour {

    [Header("Panels")]
    private GameObject Panel_Options;

    private int Control_Panel_activations;

    // Use this for initialization
    void Awake () {
        StartCoroutine("FakeUpdate");
	}

    #region Update
    //UPDATE
    IEnumerator FakeUpdate()
    {
        switch (Control_Panel_activations)
        {
            //Disable All
            case 0:
                Panel_Options.SetActive(false);
                break;
            //Solo
            case 1:
                Debug.Log("Carregando modo solo");
                SceneManager.LoadScene("Offline_Scene");
                break;
            //To Choose the music
            case 2:
                SceneManager.LoadScene("Offline_Local_Multiplayer");
                break;
            //local match or Online match?
            case 3:
                SceneManager.LoadScene("Multiplayer_Scene");
                break;
            case 4:
                //To close the game
                Application.Quit();
                break;
            case 5:
                Panel_Options.SetActive(true);
                break;
        }
        yield return new WaitForSeconds(0);
        StartCoroutine("FakeUpdate");
    }
    #endregion

    public void Getbutton(int b)
    {
        //panels receive a button value
        Control_Panel_activations = b;
        StartCoroutine("FakeUpdate");
    }
}
