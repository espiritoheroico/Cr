﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour {

    #region vars

    //Tooltiop é usado para comentar o que tal variavel/enum/bool pode fazer/////////
    [Tooltip("input mode type")]
    [SerializeField] InputMode type; //instancio um tipo InputMode,(Poderia ser Singleton)
    [SerializeField] PlayersLocalConnected unit; //Instancio um tipo PlayersLocalConnected, para ter a quantidade de players

    #endregion

    #region Enums

    #region GameMode
    private enum ModeSelect
    {
        //BASED ON MENU SELECT MODE
        solo,
        multiplayer,
        localMultiplayer
    }
    #endregion

    #region InputMode
    private enum InputMode {
        //Jogar apenas com o mouse,para jogadores solo
        Mouse,
        //Jogar apenas com o joystick,para jogadores solo
        Joystick,
        //Player 1 Jogar apenas com o mouse,recomendado para jogadores multiplayers que não sabem brincar
        OneMouseThreejoys,
        //todos jogam apenas com o joystick
        FourJoysticks
    };
    #endregion

    #region playersLocals
    private enum PlayersLocalConnected
    {
        //quantos players tem na sala local, quantos joysticks
        onePlayer,
        twoPlayers,
        ThreePlayers,
        fourPlayers

    }
    #endregion

    #endregion


    void Initiate () {

        // colocar no inicio ////ESCOLHA DE MODOS DECIDE ISSO 
        //para decidir o tipo
        switch (type)
        {
            case InputMode.Mouse:
                //alocar função
                break;
            case InputMode.Joystick:
                //alocar função
                break;
            case InputMode.OneMouseThreejoys:
                //alocar função
                break;
            case InputMode.FourJoysticks:
                //alocar função
                break;
            default:
                    break;
        }

        //decidir a quantidade de players////// INICIO TAMBEM/ DO MODO
        switch (unit)
        {
            case PlayersLocalConnected.onePlayer:
                break;
            case PlayersLocalConnected.twoPlayers:
                break;
            case PlayersLocalConnected.ThreePlayers:
                break;
            case PlayersLocalConnected.fourPlayers:
                break;
        }
    }

    

    // Update is called once per frame
    void Update () {

       
    }
}
