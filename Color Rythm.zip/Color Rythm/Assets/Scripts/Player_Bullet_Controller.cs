﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Bullet_Controller : MonoBehaviour
{


    [SerializeField]
    private ParticleSystem parBullet;

    //Button pressed to Shoot Particle
    [SerializeField]string axisFire;

    void Awake()
    {
        StartCoroutine("FakeUpdate");
        parBullet.GetComponent<ParticleSystem>();
    }

    IEnumerator FakeUpdate()
    {
        //Set Up the Fire Button
        if (Input.GetButton(axisFire))
        {
            //parBullet.
            parBullet.Emit(1);

        }
        yield return new WaitForSeconds(0.001f);
        StartCoroutine("FakeUpdate");
    }

    private void OnParticleCollision(GameObject Shoot)
    {
        //RECOGNIZE WHO´S SHOOTED
        Debug.Log("ShootingOn" + this.gameObject.tag);
        //INVOKE ONE METHOD
        //Shoot.GetComponent<TurnLight>().Invoke("Atirou", 1f);

    }
}
