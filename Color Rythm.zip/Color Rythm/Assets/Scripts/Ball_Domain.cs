﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball_Domain : MonoBehaviour {

    [SerializeField]private GameObject[] parts;
    private int currentTarget;
    GameObject target;
    Rigidbody2D rb;
    float moveH, moveV;

    Vector2 posd;


    void Awake () {

        rb = GetComponent<Rigidbody2D>();

        FindTarget();

        posd = transform.position;
    }

    //Metodo para encontrar alvo
    void FindTarget()
    {
        //RANGE TO CHOOSE
        currentTarget = Random.RandomRange(0, parts.Length);
        target = parts[currentTarget];

    }

    void Update () {

        rb.AddForce(target.transform.position *0.030f* Time.deltaTime, ForceMode2D.Force);

    }

    private void OnCollisionStay2D(Collision2D pieceCollision)
    {
        //IF COLLIDE WITH AN OBJECT
        if (pieceCollision.gameObject)
        {
            transform.Translate(posd * 5 * Time.deltaTime);
            StartCoroutine("ReturnBase");
        }
    }

    IEnumerator ReturnBase()
    {
        yield return new WaitForSeconds(3);
        FindTarget();
    }

}
