﻿using System.Collections;
using UnityEngine;

//SET UP THE PIECES 
public class TurnLight : MonoBehaviour {

    #region var
    [SerializeField]
    private Color color_change = new Color( 0,0,0);
    private Color color_default;

    #region layers
    LayerMask las;
    #endregion

    bool p1IsShooting = false;
    bool p2IsShooting = false;
    bool p3IsShooting = false;
    bool p4IsShooting = false;

    bool colorActive = false;


    #endregion
    //Voids Running
    #region Run
    void Awake () {
        //TO GET THE COLLOR DEFAULT
       color_default =  GetComponent<SpriteRenderer>().color;
    }
    #endregion
    #region collision
    private void OnCollisionEnter2D(Collision2D turn_color_on)
    {
        //color ball collision
        #region BallTouched

        if (turn_color_on.gameObject.CompareTag("ballblue"))
        {
            print("blue ball ahead");
            StartCoroutine("TurningColor");
        }
        //Collision with the RED BALL
        if (turn_color_on.gameObject.CompareTag("ballred"))
        {
            print("red ball ahead");
            StartCoroutine("TurningColor");
        }
        //Collision with the Yellow BALL
        if (turn_color_on.gameObject.CompareTag("ballyellow"))
        {
            print("yellow ball ahead");
            StartCoroutine("TurningColor");
        }
        //Collision with the GREEN BALL
        if (turn_color_on.gameObject.CompareTag("ballgreen"))
        {
            print("Green ball ahead");
            StartCoroutine("TurningColor");
        }
        #endregion
    }

    #endregion
    #region Routines
    #region PieceManager
    IEnumerator TurningColor()
    {
        GetComponent<SpriteRenderer>().color = color_change;
        yield return new WaitForSeconds(0.5f);
        GetComponent<SpriteRenderer>().color = color_default;
    }
    #endregion

    #region PointManager
    IEnumerator PointCount()
    {
        //POINT INCREASE
        yield return new WaitForSeconds(0.05f);
        Debug.Log("Point Increase");
    }
    #endregion
    //--


    void Atirou(int ID)
    {

    }
    #endregion


}
