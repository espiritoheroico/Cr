﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParticleCollisionShoot : MonoBehaviour {


    ParticleSystem shootPar;

    private void Start()
    {

    }

    private void OnParticleCollision(GameObject Shoot)
    {
        Debug.Log("get" + " " + Shoot.gameObject.tag);
        //invocar um metodo
        //Shoot.GetComponent<TurnLight>().Invoke("Atirou", 1f);
       
    }
}
