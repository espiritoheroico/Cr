﻿using System.Collections;
using UnityEngine;
//CODE CREATED BY VITOR DIAS
public class FaceMouse : MonoBehaviour {

    [SerializeField]
    bool isJoystick;
    [SerializeField]
    bool isPlayerOne;

    
    // Use this for initialization
    void Awake () {

        if (isJoystick)
        {
            StartCoroutine("FaceJoystickMode");
        }
        else
        {
           StartCoroutine("FaceMouseMode");
        }
        //Cursor.visible = false;

    }
	

    //A FAKE UPDATE
    IEnumerator FaceMouseMode()
    {
        // Get The input mouse location in the world
        var dir = Input.mousePosition - Camera.main.WorldToScreenPoint(transform.position);
        //Atan will get the angle, based in the Tangent
        var angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;
        //Object Rotation got the Forward face of the Object
        transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
        yield return new WaitForSeconds(0.01f);
        StartCoroutine("FaceMouseMode");
    }

    IEnumerator FaceJoystickMode()
    {

        if (isPlayerOne)
        {
            // Get The input mouse location in the world 
            Vector2 dir = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
            //Atan will get the angle, based in the Tangent
            var angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;

            //Object Rotation got the Forward face of the Object
            transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);

            yield return new WaitForSeconds(0.01f);
            StartCoroutine("FaceJoystickMode");
        }
   
       
    }

}
